#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")" && pwd)"
cd "$BASE"
mkdir -p app/src/main/java/com/upd app/src/main/res/values
echo "[+] project at: $BASE"
find . -type f | sort
